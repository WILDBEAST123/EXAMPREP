﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;

namespace DataBindingExamples
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        List<PersonInfo> plist = new List<PersonInfo>();

        public Window2()
        {
            InitializeComponent();
            plist.Add(new PersonInfo { PersonID = 1, PersonName = "Prince", PersonLocation = "kasba" });
            plist.Add(new PersonInfo { PersonID = 2, PersonName = "Saumya", PersonLocation = "Bhagalpur" });
            plist.Add(new PersonInfo { PersonID = 3, PersonName = "Rohit", PersonLocation = "Purnia" });
            plist.Add(new PersonInfo { PersonID = 4, PersonName = "Sakshi", PersonLocation = "jalalgarh" });
            dataGrid1.DataContext = plist;
            dataGrid1.ItemsSource = plist;
            

        }
    }
}
