﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace AnimationExample
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            DoubleAnimation da = new DoubleAnimation();
            da.From = 0;
            da.To = 360;
            da.Duration = new Duration(TimeSpan.FromSeconds(3));
            da.RepeatBehavior = RepeatBehavior.Forever;
            RotateTransform rt = new RotateTransform();
            r1.RenderTransform = rt;
            rt.BeginAnimation(RotateTransform.AngleProperty,da);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            DoubleAnimation da = new DoubleAnimation();
            da.From = 10;
            da.To = 300;
            da.Duration = new Duration(TimeSpan.FromSeconds(3));
            da.AutoReverse = true;
            da.RepeatBehavior = RepeatBehavior.Forever;
            //SkewTransform st = new SkewTransform(20, 40);
            //r2.RenderTransform = st;
            //st.BeginAnimation(SkewTransform.CenterYProperty,da);
            r2.BeginAnimation(OpacityProperty, da);
            r2.BeginAnimation(WidthProperty, da);
            r2.BeginAnimation(HeightProperty, da);

        }
    }
}
