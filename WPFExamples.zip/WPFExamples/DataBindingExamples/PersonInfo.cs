﻿

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataBindingExamples
{
    class PersonInfo
    {
        public int PersonID { get; set; }
        public string PersonName { get; set; }
        public string PersonLocation { get; set; }
    }
}
