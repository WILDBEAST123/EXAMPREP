﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FirstExample
{
    /// <summary>
    /// Interaction logic for LayoutWindow.xaml
    /// </summary>
    public partial class LayoutWindow : Window
    {
        public LayoutWindow()
        {
            InitializeComponent();
        }

        private void BtnGrid_Click(object sender, RoutedEventArgs e)
        {
            GridWindow gw = new GridWindow();
            gw.ShowDialog();
        }

        private void BtnStack_Click(object sender, RoutedEventArgs e)
        {
            StackWindow sw = new StackWindow();
            sw.ShowDialog();
        }

        private void BtnCanvas_Click(object sender, RoutedEventArgs e)
        {
            CanvasWindow cw = new CanvasWindow();
            cw.ShowDialog();
        }

        private void BtnDock_Click(object sender, RoutedEventArgs e)
        {
            DockWindow dw = new DockWindow();
            dw.ShowDialog();
        }

        private void BtnWrap_Click(object sender, RoutedEventArgs e)
        {
            WrapWindow ww = new WrapWindow();
            ww.ShowDialog();
        }
    }
}
